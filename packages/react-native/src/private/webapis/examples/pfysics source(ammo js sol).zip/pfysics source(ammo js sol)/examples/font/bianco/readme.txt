http://www.typesource.com/pOPdOG/index.htm
http://www.i.am/popdog

This freeware font from pOPdOG fONTS
contains greek characters.


e-mail: kolyris@usa.net

