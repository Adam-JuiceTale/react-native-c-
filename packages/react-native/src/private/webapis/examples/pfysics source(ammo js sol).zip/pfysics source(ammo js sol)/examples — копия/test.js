

import {ConvexObjectBreaker} from "three/addons/misc/ConvexObjectBreaker.js"



export default function Test({THREE,scene,camera}){
  
  
  let vec3 = THREE.Vector3;
  let {abs,sin} = Math;
  let boxUVUnwrap=(mesh,sourceMesh=mesh)=>{
    //Box UV unwrap by thrax... takes optional sourceMesh to use as unwrap reference bounds
    let pa = mesh.geometry.attributes.position.array;
    let na = mesh.geometry.attributes.normal.array;
    let ta = new Float32Array(pa.length*2/3);
    let n=new vec3()
    let p=new vec3()
    let sz=new vec3()
    if(!sourceMesh.geometry.boundingBox)
      sourceMesh.geometry.computeBoundingBox()
    sourceMesh.geometry.boundingBox.getSize(sz)
    for(let i=0,ui=0;i<pa.length;i+=3,ui+=2){
      p.set(pa[i],pa[i+1],pa[i+2]);
      if(sourceMesh!==mesh)
        sourceMesh.worldToLocal(mesh.localToWorld(p))
      
      p.sub(sourceMesh.geometry.boundingBox.min);
      p.divide(sz)
      n.set(abs(na[i]),abs(na[i+1]),abs(na[i+2]));
      if(n.x>=n.y){
        if(n.x>n.z){//YZ
          ta[ui]=p.y;
          ta[ui+1]=p.z
        }else{//XY
          ta[ui]=p.y
          ta[ui+1]=p.x
        }
      }else{
        if(n.y>n.z){//XZ
          ta[ui]=p.x
          ta[ui+1]=p.z
        }else{//XY
          ta[ui]=p.x
          ta[ui+1]=p.y
        }
      }
    }
    mesh.geometry.setAttribute('uv',new THREE.Float32BufferAttribute(ta,2))
  }
    
  //Set up a simple test to box unwrap a broken convex object
  
  let geo = new THREE.BoxGeometry(1,1,1,1,1,1);
  let boxMesh = new THREE.Mesh(geo,new THREE.MeshStandardMaterial({
    map:new THREE.TextureLoader().load('https://cdn.glitch.global/364206c7-9713-48db-9215-72a591a6a9bd/pexels-fwstudio-129733%20(1).jpg?v=1658926492448')
  }))
  
  boxUVUnwrap(boxMesh);//Unwrap the original mesh so that subsequent unwraps will be similar..
  
  scene.add(boxMesh);
  
  //Create the broken up meshes...
  boxMesh.userData.velocity = new THREE.Vector3(.1,.1,.1)
  boxMesh.userData.angularVelocity = new THREE.Vector3(.1,.1,.1)
  boxMesh.userData.mass = 1.;
  let breaker = new ConvexObjectBreaker();
  
  let debris = breaker.subdivideByImpact( boxMesh,
                                 new THREE.Vector3(.5,.5,0),//hit point
                                 new THREE.Vector3(0,0,1),//normal,
                                 0,
                                 2 );
  //Add the pieces to the scene...
  debris.forEach(d=>scene.add(d))

  //Unwrap their UVs with the original mesh box as the reference bounds/unwrap box
  for(let i=0;i<debris.length;i++){
    
    let d = debris[i];
    boxUVUnwrap(d,boxMesh);
    
    d.position.multiplyScalar(1.1);// Move the debris pieces around a bit so they are visible..
    d.position.z += 2
  }
  
  this.update=()=>{
    let time = performance.now()/1000;
    let bounce = abs(sin(time))+1;
    debris.forEach(d=>{
      if(!d.userData.originalPosition)
        d.userData.originalPosition = d.position.clone();
      d.position.copy(d.userData.originalPosition)
      d.position.multiplyScalar(bounce)
      
    })
  }
}